<?php 

$lang["messages_first_name"] = "الإسم الأول";
$lang["messages_last_name"] = "الأسم الأخير";
$lang["messages_message"] = "الرسالة";
$lang["messages_message_placeholder"] = "رسالتك هنا...";
$lang["messages_message_required"] = "الرسالة مطلوبة";
$lang["messages_multiple_phones"] = "  فى حالة إرسال الرسالة لأكثر من شخص قم بفصل الأرقام بعلامة الفاصلة";
$lang["messages_phone"] = "رقم المحمول";
$lang["messages_phone_number_required"] = "رقم المحمول مطلوب";
$lang["messages_phone_placeholder"] = "رقم/أرقام المحمول هنا...";
$lang["messages_sms_send"] = "إرسال SMS";
$lang["messages_successfully_sent"] = "تم إرسال الرسالة بنجاح إلى: ";
$lang["messages_unsuccessfully_sent"] = "لم يتم إرسال الرسالة بنجاح إلى: ";
