<?php 

$lang["datepicker_all_time"] = "за все время";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_custom"] = "Custom";
$lang["datepicker_from"] = "From";
$lang["datepicker_last_30"] = "Последние 30 дней";
$lang["datepicker_last_7"] = "Последние 7 дней";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Последний месяц";
$lang["datepicker_last_year"] = "в прошлом году";
$lang["datepicker_same_month_last_year"] = "Same Month Last Year";
$lang["datepicker_same_month_to_same_day_last_year"] = "Same Month To Same Day Last Year";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "В этом месяце";
$lang["datepicker_this_year"] = "В этом году";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "сегодня";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "вчера";
