<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Giriş";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Kullanıcı adı/Şifre yanlış";
$lang["login_login"] = "Giriş";
$lang["login_password"] = "Şifre";
$lang["login_username"] = "Kullanıcı Adı";
