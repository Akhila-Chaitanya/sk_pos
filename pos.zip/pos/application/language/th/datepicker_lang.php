<?php 

$lang["datepicker_all_time"] = "เวลาทั้งหมด";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "ยกเลิก";
$lang["datepicker_custom"] = "Custom";
$lang["datepicker_from"] = "From";
$lang["datepicker_last_30"] = "30 วันสุดท้าย";
$lang["datepicker_last_7"] = "7 วันสุดท้าย";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "เดือนที่แล้ว";
$lang["datepicker_last_year"] = "ปีที่แล้ว";
$lang["datepicker_same_month_last_year"] = "Same Month Last Year";
$lang["datepicker_same_month_to_same_day_last_year"] = "Same Month To Same Day Last Year";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "เดือนนี้";
$lang["datepicker_this_year"] = "ปีนี้";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "วันนี้";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "เมื่อวานนี้";
