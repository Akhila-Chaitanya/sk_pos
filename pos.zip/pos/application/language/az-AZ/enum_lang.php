<?php 

$lang["enum_half_down"] = "Half Down";
$lang["enum_half_even"] = "Half Even";
$lang["enum_half_five"] = "Half Five";
$lang["enum_half_odd"] = "Half Odd";
$lang["enum_half_up"] = "Half Up";
$lang["enum_round_down"] = "Round Down";
$lang["enum_round_up"] = "Round Up";
