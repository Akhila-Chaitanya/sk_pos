<?php 

$lang["tables_all"] = "";
$lang["tables_columns"] = "";
$lang["tables_hide_show_pagination"] = "";
$lang["tables_loading"] = "";
$lang["tables_page_from_to"] = "";
$lang["tables_refresh"] = "";
$lang["tables_rows_per_page"] = "";
$lang["tables_toggle"] = "";
